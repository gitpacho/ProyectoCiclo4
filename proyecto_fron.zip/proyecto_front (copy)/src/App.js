import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
//import Login from "./components/login/login"; login no la usamos porque tenemos el approuter que contine el login
import NavBar from "./components/navbar/navbar";
//import Card1 from "./components/card/card";

import AppRouter from "./Router/Router";

function App() {
  return (
    <div className="App">
      <NavBar />
      <AppRouter />
    </div>
  );
}

export default App;
