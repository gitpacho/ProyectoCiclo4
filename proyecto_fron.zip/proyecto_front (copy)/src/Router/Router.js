import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import PrivateRoute from "../Auth/PrivateRoute.js";
import Login from "../components/login/login";
import Empleados from "../components/empleados/index.js";

//rafc
export default function AppRouter() {
  return (
    <Router>
      <Switch>
        <Route exact path={["/", "/login"]} component={Login} />
        <PrivateRoute exact path={["/empleados"]} component={Empleados} />

        {/* Ruta de página que no existe, error 404 */}

        <Route
          path={"*"}
          component={() => (
            <h1 style={{ marginTop: 300 }}>
              {" "}
              404
              <br />
              Página no encontrada
            </h1>
          )}
        />
      </Switch>
    </Router>
  );
}
