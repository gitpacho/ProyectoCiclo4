import React from "react";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import {
  PaginationProvider,
  PaginationListStandalone,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
/* import { Row, Col } from "react-bootstrap"; */
import { request } from "../helper/helper";
import Loading from "../loading/loading";

const { SearchBar } = Search;

export default class DataGrid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      rows: [],
    };
  }
  componentDidMount() {
    this.getData();
  }
  getData() {
    this.setState({ loading: true });
    request
      .get(this.props.url)
      .then((response) => {
        this.setState({
          rows: response.data,
          loading: false,
        });
      })
      .catch((err) => {
        this.setState({ loading: false });

        console.error(err);
      });
  }
  render() {
    const options = {
      custom: true,
      totalSize: this.state.rows.length,
    };
    return (
      <ToolkitProvider
        keyField="id"
        data={this.state.rows}
        columns={this.props.columns}
        search
      >
        {(props) => (
          <div>
            <hr />
            <Loading show={this.state.loading} />

            <PaginationProvider pagination={paginationFactory(options)}>
              {({ paginationProps, paginationTableProps }) => (
                <>
                  <SizePerPageDropdownStandalone {...paginationProps} />
                  <SearchBar {...props.searchProps} />

                  <BootstrapTable
                    keyField="id"
                    data={this.state.rows}
                    columns={this.props.columns}
                    {...paginationTableProps}
                    {...props.baseProps}
                  />
                  <PaginationListStandalone {...paginationProps} />
                </>
              )}
            </PaginationProvider>
          </div>
        )}
      </ToolkitProvider>
    );
  }
}
