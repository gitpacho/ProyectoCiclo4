import Button from "@restart/ui/esm/Button";
import React from "react";
import { Container, Form, Row } from "react-bootstrap";
import { request } from "../../helper/helper";
import Loading from "../../loading/loading.js";

export default class EmpleadosCrear extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      empleados: {
        nombre: "",
        apellido_p: "",
        apellido_m: "",
        telefono: "",
        email: "",
        direccion: "",
      },
    };
  }

  setValue(index, value) {
    this.setState({
      empleados: {
        ...this.state.empleados,
        [index]: value,
      },
    });
  }

  guardarEmpleado() {
    this.setState({ loading: true });
    request
      .post("/empleados", this.state.empleados)
      .then((response) => {
        if (response.data.exito) {
          this.props.changedTab("buscar");
        }
        this.setState({ loading: false });
        console.log(response);
      })
      .catch((error) => {
        this.setState({ loading: true });
      });
  }

  render() {
    return (
      <Container id="empleados-crear-container">
        <Loading show={this.state.loading} />

        <Row>
          <h2>Crear empleado</h2>
        </Row>

        <Row>
          <Form>
            <Form.Group className="mb-3" controlId="formBasic">
              <Form.Label>Nombre</Form.Label>
              <Form.Control
                onChange={(e) => this.setValue("nombre", e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasic">
              <Form.Label>Apellido Paterno</Form.Label>
              <Form.Control
                onChange={(e) => this.setValue("apellido_p", e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasic">
              <Form.Label>Apellido Materno</Form.Label>
              <Form.Control
                onChange={(e) => this.setValue("apellido_m", e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasic">
              <Form.Label>Telefono</Form.Label>
              <Form.Control
                onChange={(e) => this.setValue("telefono", e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasic">
              <Form.Label>e-mail</Form.Label>
              <Form.Control
                onChange={(e) => this.setValue("email", e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasic">
              <Form.Label>Direccion</Form.Label>
              <Form.Control
                onChange={(e) => this.setValue("direccion", e.target.value)}
              />
            </Form.Group>

            <Button
              variant="primary"
              onClick={() => console.log(this.guardarEmpleado())}
            >
              Submit
            </Button>
          </Form>
        </Row>
      </Container>
    );
  }
}
