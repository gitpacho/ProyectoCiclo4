import React from "react";
import { Container, Nav, Row } from "react-bootstrap";
import "./empleados.css";
import EmpleadosBuscar from "./CRUD/buscar";
import EmpleadosCrear from "./CRUD/crear";
export default class Empleados extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currenTap: "buscar",
    };
  }
  changedTab(tab) {
    this.setState({ currenTap: tab });
  }

  render() {
    return (
      <Container id="empleados-container">
        <Row>
          <Nav
            fill
            variant="tabs"
            defaultActiveKey="/buscar"
            onSelect={(eventKey) => this.setState({ currenTap: eventKey })}
          >
            <Nav.Item>
              <Nav.Link eventKey="buscar">Buscar</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="crear">Crear</Nav.Link>
            </Nav.Item>
          </Nav>
        </Row>

        <Row>
          {this.state.currenTap === "buscar" ? (
            <EmpleadosBuscar />
          ) : (
            <EmpleadosCrear changedTab={(tab) => this.changedTab(tab)} />
          )}
        </Row>
      </Container>
    );
  }
}
