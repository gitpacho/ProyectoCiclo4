import React from "react";
import axios from "axios";
import { Form, Button, Container, Col, Row } from "react-bootstrap";
import { APIHOST as host } from "../../app.json";
import "./login.css";
import { isNull } from "util";
import Cookies from "universal-cookie";
import { calcularExpiracion } from "../helper/helper"; /* Funcion para calcular el tiempo de vidad del token */
import Loading from "../loading/loading";

const Cookie = new Cookies();
// para crear este constructor de componente se digita "ccc" y luego enter
export default class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      usuario: "",
      contraseña: "",
    };
  }

  iniciarSecion() {
    this.setState({ loading: true });
    axios
      .post(`${host}/usuarios/login`, {
        usuario: this.state.usuario,
        pass: this.state.contraseña,
      })
      .then((response) => {
        console.log(response);
        if (isNull(response.data.token)) {
          alert("Usuario y/o contraseña invalidos");
        } else {
          Cookie.set("_s", response.data.token, {
            path: "/",
            expires: calcularExpiracion(),
          }); /* Nombre del cookie temporal _s */
          this.props.history.push("/empleados");
        }
        this.setState({ loading: false });
      })
      .catch((err) => {
        console.log(err);
        this.setState({ loading: false });
      });
    /* alert(
      `Usuario: ${this.state.usuario} - Contraseña: ${this.state.contraseña}`
    ); */
  }

  render() {
    return (
      <Container id="login-container" style={{ marginTop: 100 }}>
        <Loading show={this.state.loading} />
        <Row>
          <Col col="col-6">
            <h2>Iniciar Sesión</h2>

            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Usuario</Form.Label>
                <Form.Control
                  onChange={(e) => this.setState({ usuario: e.target.value })}
                  placeholder="Ingrese usuario"
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Contraseña</Form.Label>
                <Form.Control
                  onChange={(e) =>
                    this.setState({ contraseña: e.target.value })
                  }
                  type="password"
                  placeholder="Ingrese contraseña"
                />
              </Form.Group>
              <Button
                variant="primary"
                style={{
                  marginTop: 20,
                  width: "100%",
                }}
                onClick={() => {
                  this.iniciarSecion();
                }}
              >
                Login
              </Button>
            </Form>
          </Col>
        </Row>
      </Container>
    );
  }
}
